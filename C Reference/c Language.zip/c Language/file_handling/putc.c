#include<stdio.h>
#include<string.h>

int main()
{

   FILE *fp,*fp1;
   char str[100],str1[100];
   char ch;   
   int chara=0,newline=0,tab=0,space=0;
		
  /* //strcpy(str,"harshal chandile\t\n\n");	


//File is taken to append operation....
   fp=fopen("new.txt","a+");

//If any flaws in opening...
   if(fp==NULL)
	printf("\nfile error\n");

//Getting data from user....
   printf("\n Enter the data\n");
   gets(str1);
   //fprintf(fp,"%s",str);   
   fprintf(fp,"%s",str1);   
   fclose(fp);

*/
printf("\n\n\t********** Printing data from file.*********\t\n\n");
//Taking for reading...
   fp=fopen("file.c","r");
   fp1=fopen("file.txt","w");
 //If any flaws in opening...
   if(fp==NULL)
	printf("\nfile error\n");
   else
	{	
		  do
		   {
		
		   if(ch=='\n')
			newline++;
		   else if(ch=='\t')
			tab++;
		   else if(ch==' ')
			space++;
		   else
			chara++;
		   printf("%c",ch);
	  	   
		   if(isalnum(ch))
			{
				putc(ch,fp1);

			}

		   }while((ch=getc(fp))!=EOF);

	}


//printing no of ...... data.........
printf("\n\t....********quntity displaying*********.....\n No. of characters in file.. %d ...\n No. of newlines in file..%d ...\n No. of tab's %d...\n No. of spaces %d...\n",chara,newline,tab,space);
fclose(fp);

//removedddddddddddddd

printf("\n\n\t********** Printing data from file.*********\t\n\n");
//Taking for reading...

   fp1=fopen("file.txt","r");
 //If any flaws in opening...
   if(fp1==NULL)
	printf("\nfile error\n");
   else
	{
 do
		   {
		
		   if(ch=='\n')
			newline++;
		   else if(ch=='\t')
			tab++;
		   else if(ch==' ')
			space++;
		   else
			chara++;
		   printf("%c",ch);
	  	   
		   
		   }while((ch=getc(fp1))!=EOF);
 
}

//printing no of ...... data.........
printf("\n\t....********quntity displaying*********.....\n No. of characters in file.. %d ...\n No. of newlines in file..%d ...\n No. of tab's %d...\n No. of spaces %d...\n",chara,newline,tab,space);
fclose(fp1);



return 0;

}
