#include<stdio.h>
#include<string.h>
#include<ctype.h>
int main()
{
	FILE *fp;
	int tab=0,space=0,alpha=0,newline=0,num=0,lower=0,upper=0;
	char ch,str[100],str1[100];
	
	printf("\n Enter the message to be encoded\n");
	gets(str);
	fp=fopen("n.txt","w");
	fprintf(fp,"%s",str);
	
	fclose(fp);


	fp=fopen("n.txt","r");
	do
{
	if(ch=='\n')
		newline++;
	else if(ch=='\t')
		tab++;
	else if(ch==' ')
		space++;
	else if(isalnum(ch))
		alpha++;
	else if(islower(ch))
		lower++;
	else if(isupper(ch))
		upper++;
	printf("\n%c",ch);
	printf("\n");
	putchar(toupper(ch));


}while((ch=getc(fp))!= EOF);

printf("\n newlines are..%d\n tabs are %d \nspaces are %d \n alphanumeric are %d\n lower cases %d \n upper cases %d\n.",newline,tab,space,alpha,lower,upper);
fclose(fp);


return 0;
}
